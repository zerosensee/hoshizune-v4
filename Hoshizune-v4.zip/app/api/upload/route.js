/**
 * API: Загрузка аватара.
 * POST — multipart/form-data с файлом аватара
 * Лимит: 20 МБ для обычных пользователей
 */
import { NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import {
  getProfileById,
  updateProfile,
} from '@/lib/bio-repository';
import {
  MAX_AVATAR_SIZE,
  ALLOWED_AVATAR_TYPES,
} from '@/lib/constants';

export async function POST(request) {
  try {
    const userId =
      request.cookies.get('hoshizune_uid')?.value;

    if (!userId) {
      return NextResponse.json(
        { error: 'Не авторизован' },
        { status: 401 }
      );
    }

    const profile = getProfileById(userId);
    if (!profile) {
      return NextResponse.json(
        { error: 'Профиль не найден' },
        { status: 404 }
      );
    }

    const formData = await request.formData();
    const file = formData.get('avatar');

    if (!file || !(file instanceof File)) {
      return NextResponse.json(
        { error: 'Файл не предоставлен' },
        { status: 400 }
      );
    }

    /* Проверка размера (20 МБ для обычных) */
    if (!profile.isOwner && file.size > MAX_AVATAR_SIZE) {
      return NextResponse.json(
        {
          error: `Макс. размер файла: ${
            MAX_AVATAR_SIZE / 1024 / 1024
          } МБ`,
        },
        { status: 413 }
      );
    }

    /* Проверка типа */
    if (!ALLOWED_AVATAR_TYPES.includes(file.type)) {
      return NextResponse.json(
        {
          error:
            'Допустимые форматы: JPEG, PNG, WebP, GIF',
        },
        { status: 400 }
      );
    }

    /* Сохранение файла */
    const ext = file.name.split('.').pop() || 'webp';
    const filename = `${uuidv4()}.${ext}`;
    const uploadDir = path.join(
      process.cwd(),
      'public',
      'uploads'
    );

    await mkdir(uploadDir, { recursive: true });

    const buffer = Buffer.from(
      await file.arrayBuffer()
    );

    const filePath = path.join(uploadDir, filename);
    await writeFile(filePath, buffer);

    /* Обновление профиля */
    const avatarUrl = `/uploads/${filename}`;
    updateProfile(userId, {
      avatarPath: avatarUrl,
    });

    return NextResponse.json({
      avatarPath: avatarUrl,
    });
  } catch (error) {
    console.error(
      'Ошибка загрузки аватара:',
      error
    );
    return NextResponse.json(
      { error: 'Ошибка сервера' },
      { status: 500 }
    );
  }
}
